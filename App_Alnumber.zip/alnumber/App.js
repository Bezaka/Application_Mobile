import 'react-native-gesture-handler';
import React, { useState } from 'react';
import { View, Text, Button, TextInput, Switch, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Générateur de Nombres Aléatoires</Text>
      <Button
        title="Lancer"
        onPress={() => navigation.navigate('Generator')}
      />
    </View>
  );
};

const GeneratorScreen = ({ navigation }) => {
  const [min, setMin] = useState(1);
  const [max, setMax] = useState(1000);
  const [decimal, setDecimal] = useState(0);
  const [repeat, setRepeat] = useState(false);
  const [generatedNumbers, setGeneratedNumbers] = useState([]);

  const generateNumber = () => {
    let number = parseFloat((Math.random() * (max - min) + min).toFixed(decimal));
    if (!repeat && generatedNumbers.includes(number)) {
      generateNumber();
    } else {
      setGeneratedNumbers([...generatedNumbers, number]);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={styles.backButton}>Retour</Text>
      </TouchableOpacity>
      <View style={styles.inputContainer}>
        <Text>Nombre minimum</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(min)}
          onChangeText={text => setMin(Number(text))}
        />
        <Text>Nombre maximum</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(max)}
          onChangeText={text => setMax(Number(text))}
        />
        <Text>Décimaux</Text>
        <View style={styles.decimalContainer}>
          <Button title="-" onPress={() => setDecimal(decimal > 0 ? decimal - 1 : 0)} />
          <Text style={styles.decimalText}>{decimal}</Text>
          <Button title="+" onPress={() => setDecimal(decimal + 1)} />
        </View>
        <Text>Répéter des nombres</Text>
        <Switch
          value={repeat}
          onValueChange={value => setRepeat(value)}
        />
      </View>
      <Button title="Produire" onPress={generateNumber} />
      <View style={styles.resultContainer}>
        {generatedNumbers.map((num, index) => (
          <Text key={index} style={styles.number}>{num}</Text>
        ))}
      </View>
      <TouchableOpacity style={styles.quitButton} onPress={() => navigation.goBack()}>
        <Text style={styles.quitButtonText}>Quitter</Text>
      </TouchableOpacity>
    </View>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'AlNumber' }} />
        <Stack.Screen name="Generator" component={GeneratorScreen} options={{ title: 'AlNumber' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#4f53',
  },
  backButton: {
    color: '#007AFF',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 10,
    padding: 5,
  },
  decimalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  decimalText: {
    marginHorizontal: 10,
  },
  resultContainer: {
    marginVertical: 20,
    alignItems: 'center',
  },
  number: {
    fontSize: 18,
    marginVertical: 2,
  },
  quitButton: {
    backgroundColor: '#d9534f',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  quitButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default App;
