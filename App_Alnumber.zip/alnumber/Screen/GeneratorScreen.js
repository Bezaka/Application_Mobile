import React, { useState } from 'react';
import { View, Text, TextInput, Button, Switch, StyleSheet, TouchableOpacity } from 'react-native';

const GeneratorScreen = ({ navigation }) => {
  const [min, setMin] = useState(1);
  const [max, setMax] = useState(1000);
  const [decimal, setDecimal] = useState(0);
  const [repeat, setRepeat] = useState(false);
  const [generatedNumbers, setGeneratedNumbers] = useState([]);

  const generateNumber = () => {
    let number = parseFloat((Math.random() * (max - min) + min).toFixed(decimal));
    if (!repeat && generatedNumbers.includes(number)) {
      generateNumber();
    } else {
      setGeneratedNumbers([...generatedNumbers, number]);
    }
  };

  return (
    <View style={styles.container}>
      <Button title="Retour" onPress={() => navigation.goBack()} />
      <View style={styles.inputContainer}>
        <Text>Nombre minimum</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(min)}
          onChangeText={text => setMin(Number(text))}
        />
        <Text>Nombre maximum</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={String(max)}
          onChangeText={text => setMax(Number(text))}
        />
        <Text>Décimaux</Text>
        <View style={styles.decimalContainer}>
          <Button title="-" onPress={() => setDecimal(decimal > 0 ? decimal - 1 : 0)} />
          <Text style={styles.decimalText}>{decimal}</Text>
          <Button title="+" onPress={() => setDecimal(decimal + 1)} />
        </View>
        <Text>Répéter des nombres</Text>
        <Switch
          value={repeat}
          onValueChange={value => setRepeat(value)}
        />
      </View>
      <Button title="Produire" onPress={generateNumber} />
      <View style={styles.resultContainer}>
        {generatedNumbers.map((num, index) => (
          <Text key={index} style={styles.number}>{num}</Text>
        ))}
      </View>
      <TouchableOpacity style={styles.quitButton} onPress={() => navigation.goBack()}>
        <Text style={styles.quitButtonText}>Quiter</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    borderBottomWidth: 1,
    marginBottom: 10,
    padding: 5,
  },
  decimalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  decimalText: {
    marginHorizontal: 10,
  },
  resultContainer: {
    marginVertical: 20,
    alignItems: 'center',
  },
  number: {
    fontSize: 18,
    marginVertical: 2,
  },
  quitButton: {
    backgroundColor: '#d9534f',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  quitButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default GeneratorScreen;
